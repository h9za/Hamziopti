@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is needed once. Install the LTS version from https://nodejs.org then run this file again.
  start https://nodejs.org
  pause
  exit /b
)
call npm install
call npm run build
echo.
echo Done. Your Hamziopti.exe is in the "dist" folder.
pause
