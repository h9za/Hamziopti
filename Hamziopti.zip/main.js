const { app, BrowserWindow, Menu, dialog } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const crypto = require('crypto');
const port = 49152 + Math.floor(Math.random() * 15000);
const token = crypto.randomBytes(16).toString('hex');
const base = `http://127.0.0.1:${port}`;
let ps;

function startBackend() {
  ps = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
    '-File', path.join(__dirname, 'Hamziopti.ps1'), '-NoBrowser', '-Port', String(port), '-Token', token], { windowsHide: true });
}
async function ready() {
  for (let i = 0; i < 60; i++) {
    try { const r = await fetch(base + '/api/ping', { headers: { 'X-Token': token } }); if (r.ok) return true; } catch {}
    await new Promise(r => setTimeout(r, 500));
  }
  return false;
}
app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  startBackend();
  if (!(await ready())) {
    dialog.showErrorBox('Hamziopti', 'The backend did not start. See Hamziopti-error.log next to the app.');
    return app.quit();
  }
  const win = new BrowserWindow({ width: 1320, height: 840, minWidth: 1000, minHeight: 650, backgroundColor: '#07070f',
    title: 'Hamziopti', icon: path.join(__dirname, 'Hamziopti.ico'), autoHideMenuBar: true, webPreferences: { backgroundThrottling: false } });
  win.loadURL(base + '/?t=' + token);
});
app.on('window-all-closed', async () => {
  try { await fetch(base + '/api/quit', { headers: { 'X-Token': token } }); } catch {}
  try { ps && ps.kill(); } catch {}
  app.quit();
});
