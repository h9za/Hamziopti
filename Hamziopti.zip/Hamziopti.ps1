param([switch]$Shortcut,[switch]$NoBrowser,[int]$Port=0,[string]$Token='')
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
Add-Type -AssemblyName System.Windows.Forms
function Fail($m) {
  try { Add-Content (Join-Path $Root 'Hamziopti-error.log') "$(Get-Date -f s) $m" } catch {}
  [void][System.Windows.Forms.MessageBox]::Show("Hamziopti could not start:`n`n$m`n`n(also saved in Hamziopti-error.log)", 'Hamziopti')
}
try {
  if ($Shortcut) {
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Hamziopti.lnk'))
    $s.TargetPath = 'powershell.exe'
    $s.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Root\Hamziopti.ps1`""
    $s.WorkingDirectory = $Root; $s.IconLocation = "$Root\Hamziopti.ico"; $s.Save()
    [void][System.Windows.Forms.MessageBox]::Show('Desktop shortcut "Hamziopti" created.', 'Hamziopti'); exit
  }

  $Data = Join-Path $env:APPDATA 'Hamziopti'
  New-Item -ItemType Directory -Force $Data | Out-Null
  $BackupFile = Join-Path $Data 'backup.json'

  # Safety: these registry areas are never touched
  $Blocked = 'Defender|Firewall|Security Center|EnableLUA|Policies|Lsa|DeviceGuard|Overclock'
  $PowerHigh = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
  $RunKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
  $ApprKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'

  $Tweaks = @(
    @{ id = 'power'; name = 'High performance power plan'; desc = 'Stops Windows from throttling the CPU to save power.'; cat = 'power' },
    @{ id = 'gamemode'; name = 'Game Mode on'; desc = 'Lets Windows prioritise your game over background tasks.'; cat = 'gaming'
       reg = @(@('HKCU:\Software\Microsoft\GameBar', 'AutoGameModeEnabled', 1), @('HKCU:\Software\Microsoft\GameBar', 'AllowAutoGameMode', 1)) },
    @{ id = 'dvr'; name = 'Background game recording off'; desc = 'Xbox Game Bar stops recording in the background.'; cat = 'gaming'
       reg = @(@('HKCU:\System\GameConfigStore', 'GameDVR_Enabled', 0), @('HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR', 'AppCaptureEnabled', 0)) },
    @{ id = 'mouse'; name = 'Mouse acceleration off'; desc = 'Raw 1:1 mouse movement for aiming. Applies after you sign out and in.'; cat = 'gaming'
       reg = @(@('HKCU:\Control Panel\Mouse', 'MouseSpeed', '0'), @('HKCU:\Control Panel\Mouse', 'MouseThreshold1', '0'), @('HKCU:\Control Panel\Mouse', 'MouseThreshold2', '0')) },
    @{ id = 'transparency'; name = 'Window transparency off'; desc = 'Saves a little GPU work in Windows itself.'; cat = 'visual'
       reg = @(,@('HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize', 'EnableTransparency', 0)) }
  )

  function Get-Backup { if (Test-Path $BackupFile) { @(Get-Content $BackupFile -Raw | ConvertFrom-Json) } else { @() } }
  function Save-Backup($l) { ConvertTo-Json -InputObject @($l) -Depth 5 | Set-Content $BackupFile -Encoding UTF8 }
  function Get-Val($p, $n) { (Get-ItemProperty -Path $p -Name $n -ErrorAction SilentlyContinue).$n }
  function Set-Reg($p, $n, $v) {
    if ($p -match $Blocked) { throw "Blocked protected path: $p" }
    if (-not (Test-Path $p)) { New-Item -Path $p -Force | Out-Null }
    $t = if ($v -is [int]) { 'DWord' } else { 'String' }
    Set-ItemProperty -Path $p -Name $n -Value $v -Type $t
  }
  function Get-Plan { $o = (powercfg /getactivescheme) -join ' '; if ($o -match '([0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12})') { $Matches[1] } else { $null } }

  function Invoke-Apply($ids) {
    $bk = [System.Collections.ArrayList]@(Get-Backup); $res = @()
    foreach ($id in $ids) {
      $tw = $Tweaks | Where-Object { $_.id -eq $id }
      if (-not $tw -or ($bk | Where-Object { $_.tweak -eq $id })) { continue }
      $done = @()
      try {
        if ($id -eq 'power') {
          $old = Get-Plan; powercfg /setactive $PowerHigh
          if ((Get-Plan) -ne $PowerHigh) { throw 'Windows refused the plan' }
          $done += @{ tweak = $id; path = 'powerplan'; name = ''; existed = $true; old = $old }
        } else {
          foreach ($r in $tw.reg) {
            $old = Get-Val $r[0] $r[1]
            $done += @{ tweak = $id; path = $r[0]; name = $r[1]; existed = ($null -ne $old); old = $old }
            Set-Reg $r[0] $r[1] $r[2]
            if ("$(Get-Val $r[0] $r[1])" -ne "$($r[2])") { throw "Could not verify $($r[1])" }
          }
        }
        foreach ($d in $done) { [void]$bk.Add($d) }
        $res += @{ id = $id; ok = $true }
      } catch {
        foreach ($d in $done) { Undo-Entry $d }
        $res += @{ id = $id; ok = $false; error = $_.Exception.Message }
      }
    }
    Save-Backup $bk; return $res
  }
  function Undo-Entry($e) {
    if ($e.path -eq 'powerplan') { if ($e.old) { powercfg /setactive $e.old } }
    elseif ($e.existed) { Set-Reg $e.path $e.name $e.old }
    else { Remove-ItemProperty -Path $e.path -Name $e.name -ErrorAction SilentlyContinue }
  }
  function Invoke-Restore {
    $bk = @(Get-Backup); [array]::Reverse($bk); $n = 0
    foreach ($e in $bk) { try { Undo-Entry $e; $n++ } catch {} }
    Save-Backup @(); return $n
  }
  function Get-Startup {
    $items = @(); if (-not (Test-Path $RunKey)) { return $items }
    $p = Get-ItemProperty $RunKey
    foreach ($n in ($p.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })) {
      $b = Get-Val $ApprKey $n.Name
      $items += @{ name = $n.Name; cmd = "$($n.Value)"; enabled = -not ($b -and $b[0] -eq 3) }
    }
    return $items
  }
  function Set-Startup($name, $on) {
    if (-not (Test-Path $ApprKey)) { New-Item $ApprKey -Force | Out-Null }
    $bytes = [byte[]](@($(if ($on) { 2 } else { 3 })) + (@(0) * 11))
    Set-ItemProperty -Path $ApprKey -Name $name -Value $bytes -Type Binary
  }
  function Get-Scan {
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $os = Get-CimInstance Win32_OperatingSystem
    $bb = Get-CimInstance Win32_BaseBoard
    $c = Get-PSDrive C
    @{
      cpu = $cpu.Name.Trim(); cores = "$($cpu.NumberOfCores) cores / $($cpu.NumberOfLogicalProcessors) threads"
      gpu = (@(Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }) -join ', ')
      ram = "$([math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)) GB"
      board = "$($bb.Manufacturer) $($bb.Product)"; bios = (Get-CimInstance Win32_BIOS).SMBIOSBIOSVersion
      os = "$($os.Caption) (build $($os.BuildNumber))"
      disk = "$([math]::Round($c.Free / 1GB, 1)) GB free of $([math]::Round(($c.Free + $c.Used) / 1GB, 1)) GB"
      plan = (((powercfg /getactivescheme) -join ' ') -replace '.*\((.*)\).*', '$1')
    }
  }
  function Invoke-Clean {
    $cut = (Get-Date).AddDays(-1); $n = 0; $sz = 0
    Get-ChildItem $env:TEMP -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $cut } | ForEach-Object {
      try { $l = $_.Length; Remove-Item $_.FullName -Force -ErrorAction Stop; $n++; $sz += $l } catch {}
    }
    @{ files = $n; mb = [math]::Round($sz / 1MB, 1) }
  }


  # ================= OVERCLOCK LAB: safety controller + tuning =================
  $OcFile = Join-Path $Data 'oc-state.json'
  $Lim = @{ gpuTemp = 83; cpuTemp = 92; capPct = 110; stepPct = 5 }   # hard limits, not changeable by the UI
  $Smi = $null
  foreach ($p in @("$env:SystemRoot\System32\nvidia-smi.exe", "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe")) { if (Test-Path $p) { $Smi = $p; break } }
  if (-not $Smi) { $gc = Get-Command nvidia-smi -ErrorAction SilentlyContinue; if ($gc) { $Smi = $gc.Source } }
  $script:BurnOk = $true
  try { Add-Type -TypeDefinition @'
using System; using System.Diagnostics; using System.Threading;
public static class Burn {
  public static volatile bool Stop; public static long Iter, Err, MemErr, MemPass; public static int Running;
  static ulong Calc() { ulong x = 1469598103934665603UL; for (int i = 0; i < 3000000; i++) { x ^= (ulong)i; x *= 1099511628211UL; } return x; }
  static ulong Expected = Calc();
  public static void Reset() { Stop = false; Iter = 0; Err = 0; MemErr = 0; MemPass = 0; Running = 0; }
  public static void Start(int ms, int n) {
    Interlocked.Add(ref Running, n);
    for (int t = 0; t < n; t++) {
      Thread th = new Thread(() => {
        Stopwatch sw = Stopwatch.StartNew();
        while (sw.ElapsedMilliseconds < ms && !Stop) { if (Calc() != Expected) Interlocked.Increment(ref Err); Interlocked.Increment(ref Iter); }
        Interlocked.Decrement(ref Running); });
      th.IsBackground = true; th.Priority = ThreadPriority.BelowNormal; th.Start();
    }
  }
  public static void StartMem(int ms, int mb) {
    Interlocked.Add(ref Running, 1);
    Thread th = new Thread(() => {
      Stopwatch sw = Stopwatch.StartNew(); byte[] b = new byte[mb * 1024 * 1024]; byte[] pats = new byte[] { 0x00, 0xFF, 0xAA, 0x55 };
      while (!Stop && sw.ElapsedMilliseconds < ms) {
        foreach (byte p in pats) {
          for (int i = 0; i < b.Length; i++) b[i] = p;
          for (int i = 0; i < b.Length; i++) if (b[i] != p) Interlocked.Increment(ref MemErr);
          if (Stop) break;
        }
        Interlocked.Increment(ref MemPass);
      }
      Interlocked.Decrement(ref Running); });
    th.IsBackground = true; th.Start();
  }
}
'@ -Language CSharp } catch { $script:BurnOk = $false }

  function Test-Admin { ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) }
  function Num($x) { $d = 0.0; if ([double]::TryParse("$x", [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { $d } else { $null } }
  function Load-Oc {
    $o = @{ status = 'idle'; original = $null; lastGood = $null; baseline = $null; rejected = @(); log = @() }
    if (Test-Path $OcFile) { try { $j = Get-Content $OcFile -Raw | ConvertFrom-Json
      foreach ($k in 'status', 'original', 'lastGood', 'baseline') { $o[$k] = $j.$k }; $o.rejected = @($j.rejected); $o.log = @($j.log) } catch {} }
    $o
  }
  function Save-Oc { ConvertTo-Json -InputObject $script:OC -Depth 5 | Set-Content $OcFile -Encoding UTF8 }
  function OcLog($m) { $script:OC.log = @(@($script:OC.log) + "$(Get-Date -f 'HH:mm:ss') $m" | Select-Object -Last 60); Save-Oc }
  function Get-Gpu {
    if (-not $Smi) { return $null }
    try {
      $q = & $Smi '--query-gpu=name,temperature.gpu,power.draw,power.limit,power.default_limit,power.min_limit,power.max_limit,clocks.gr,clocks.max.gr,utilization.gpu' '--format=csv,noheader,nounits' 2>$null | Select-Object -First 1
      $f = "$q" -split ',\s*'; if ($f.Count -lt 10) { return $null }
      @{ name = $f[0]; temp = (Num $f[1]); draw = (Num $f[2]); plim = (Num $f[3]); pdef = (Num $f[4]); pmin = (Num $f[5]); pmax = (Num $f[6]); clock = (Num $f[7]); maxclock = (Num $f[8]); util = (Num $f[9]) }
    } catch { $null }
  }
  function Get-Telemetry {
    $g = Get-Gpu; $c = Get-CimInstance Win32_Processor | Select-Object -First 1; $ct = $null
    try { $z = Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop | Select-Object -First 1; $ct = [math]::Round($z.CurrentTemperature / 10 - 273.15, 0) } catch {}
    if ($null -ne $ct -and ($ct -lt 5 -or $ct -gt 125)) { $ct = $null }
    @{ gpuTemp = $g.temp; gpuPower = $g.draw; gpuClock = $g.clock; gpuUtil = $g.util; cpuTemp = $ct; cpuLoad = $c.LoadPercentage; cpuClock = $c.CurrentClockSpeed }
  }
  # Independent safety controller: validates every proposal against hardware-reported limits
  function Test-Proposal($w) {
    if (-not (Test-Admin)) { return 'Administrator rights are required. Close the app, right-click it and choose Run as administrator.' }
    $g = Get-Gpu
    if (-not $g -or $null -eq $g.pdef -or $null -eq $g.pmax) { return 'GPU power limits are not readable, so tuning is disabled.' }
    if (-not $script:OC.baseline) { return 'Record a baseline at stock settings first.' }
    if ($script:OC.status -eq 'recover') { return 'A previous rollback could not be verified. Restart your PC before tuning again.' }
    $b = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
    if ($b -and $b.BatteryStatus -eq 1) { return 'Plug in AC power first.' }
    $cap = [math]::Min($g.pmax, [math]::Floor($g.pdef * $Lim.capPct / 100))
    if ($w -gt $cap) { return "Requested $w W is above the safety cap of $cap W." }
    if ($w -lt $g.pdef) { return 'Below stock is not an overclock.' }
    if ($w -gt ($g.plim + [math]::Ceiling($g.pdef * $Lim.stepPct / 100))) { return 'Step is larger than 5% of stock.' }
    if ($null -ne $g.temp -and $g.temp -ge ($Lim.gpuTemp - 8)) { return "GPU is already at $($g.temp) C. Let it cool down first." }
    return $null
  }
  function Set-GpuPower($w) {
    try { $null = & $Smi -pl $w 2>&1 } catch {}
    Start-Sleep -Milliseconds 800; $g = Get-Gpu
    [bool]($g -and $null -ne $g.plim -and [math]::Abs($g.plim - $w) -lt 1.5)
  }
  function Invoke-OcRollback($toStock = $false) {
    $t = if ($toStock) { $script:OC.original } else { $script:OC.lastGood }
    if ($null -eq $t) { if ($toStock) { $script:OC.status = 'idle'; Save-Oc }; return $true }
    $ok = Set-GpuPower ([double]$t); if (-not $ok) { $ok = Set-GpuPower ([double]$t) }
    if ($ok) { OcLog "Rollback to $t W verified"; if ($toStock) { $script:OC.status = 'idle' } }
    else { OcLog 'ROLLBACK NOT VERIFIED. Restart the PC.'; $script:OC.status = 'recover' }
    Save-Oc; return $ok
  }
  function Invoke-OcStep($w) {
    $why = Test-Proposal $w
    if ($why) { OcLog "Safety controller rejected $w W: $why"; return @{ ok = $false; error = $why } }
    $g = Get-Gpu
    if ($script:OC.status -ne 'tuning') { $script:OC.original = $g.plim; $script:OC.lastGood = $g.plim; $script:OC.status = 'tuning' }
    Save-Oc
    if (Set-GpuPower $w) { OcLog "GPU power limit set to $w W (verified)"; return @{ ok = $true; watts = $w } }
    OcLog "Could not verify $w W"; [void](Invoke-OcRollback)
    return @{ ok = $false; error = 'The new limit could not be verified, so it was rolled back.' }
  }
  $script:Test = @{ active = $false; done = $false; kind = ''; secs = 0; end = [datetime]::MinValue; aborted = $null; result = $null; peakGpu = 0; peakCpu = 0; tel = $null }
  $script:lastMon = [datetime]::MinValue
  function Invoke-Monitor {
    if (((Get-Date) - $script:lastMon).TotalMilliseconds -lt 900) { return }
    $script:lastMon = Get-Date; $T = $script:Test
    if (-not $T.active) { return }
    $tel = Get-Telemetry; $T.tel = $tel
    if ($null -ne $tel.gpuTemp -and $tel.gpuTemp -gt $T.peakGpu) { $T.peakGpu = $tel.gpuTemp }
    if ($null -ne $tel.cpuTemp -and $tel.cpuTemp -gt $T.peakCpu) { $T.peakCpu = $tel.cpuTemp }
    $errs = 0; if ($script:BurnOk) { $errs = [Burn]::Err + [Burn]::MemErr }
    $why = $null
    if ($null -ne $tel.gpuTemp -and $tel.gpuTemp -ge $Lim.gpuTemp) { $why = "GPU reached $($tel.gpuTemp) C (limit $($Lim.gpuTemp) C)" }
    elseif ($null -ne $tel.cpuTemp -and $tel.cpuTemp -ge $Lim.cpuTemp) { $why = "CPU reached $($tel.cpuTemp) C (limit $($Lim.cpuTemp) C)" }
    elseif ($errs -gt 0) { $why = 'Computation or memory errors detected' }
    if ($why) {
      if ($script:BurnOk) { [Burn]::Stop = $true }
      $T.aborted = $why; $T.active = $false; OcLog "ABORTED: $why"
      if ($script:OC.status -eq 'tuning') { [void](Invoke-OcRollback) }
      return
    }
    if ((Get-Date) -ge $T.end) {
      if ($script:BurnOk) { [Burn]::Stop = $true }
      $T.active = $false; $T.done = $true
      $it = 0; $mp = 0; if ($script:BurnOk) { $it = [Burn]::Iter; $mp = [Burn]::MemPass }
      $T.result = @{ cpuRate = [math]::Round($it / [math]::Max(1, $T.secs), 1); memPasses = $mp }
      OcLog "Test finished: $($T.kind), no errors, peak GPU $($T.peakGpu) C"
    }
  }
  function Start-OcTest($kind, $secs) {
    if ($script:Test.active) { return @{ ok = $false; error = 'A test is already running' } }
    if ($kind -notin 'cpu', 'mem', 'gpu', 'combo') { return @{ ok = $false; error = 'Unknown test' } }
    if (-not $script:BurnOk -and $kind -ne 'gpu') { return @{ ok = $false; error = 'The test engine could not be compiled on this PC' } }
    $secs = [math]::Min(300, [math]::Max(10, $secs)); $T = $script:Test
    $T.active = $true; $T.done = $false; $T.kind = $kind; $T.secs = $secs; $T.aborted = $null; $T.result = $null; $T.peakGpu = 0; $T.peakCpu = 0
    $T.end = (Get-Date).AddSeconds($secs)
    if ($script:BurnOk) {
      [Burn]::Reset()
      if ($kind -in 'cpu', 'combo') { [Burn]::Start($secs * 1000, [math]::Max(1, [Environment]::ProcessorCount - 1)) }
      if ($kind -in 'mem', 'combo') { $mb = [int][math]::Min(512, [math]::Max(64, (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1024 / 4)); [Burn]::StartMem($secs * 1000, $mb) }
    }
    OcLog "Test started: $kind, $secs s"; @{ ok = $true }
  }
  function Get-OcStatus {
    $T = $script:Test; $rem = 0; if ($T.active) { $rem = [int][math]::Max(0, ($T.end - (Get-Date)).TotalSeconds) }
    $errs = 0; if ($script:BurnOk) { $errs = [Burn]::Err + [Burn]::MemErr }
    $tel = if ($T.active -and $T.tel) { $T.tel } else { Get-Telemetry }
    @{ test = @{ active = $T.active; done = $T.done; kind = $T.kind; remaining = $rem; aborted = $T.aborted; result = $T.result; errors = $errs; peakGpu = $T.peakGpu }
       tel = $tel; oc = @{ status = $script:OC.status; original = $script:OC.original; lastGood = $script:OC.lastGood; baseline = $script:OC.baseline; rejected = @($script:OC.rejected); log = @($script:OC.log) } }
  }
  function Get-OcScan {
    $g = Get-Gpu; $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1; $ram = @(Get-CimInstance Win32_PhysicalMemory)
    $bb = Get-CimInstance Win32_BaseBoard; $bios = Get-CimInstance Win32_BIOS; $tel = Get-Telemetry; $items = @(); $gpuInfo = $null
    if ($g -and $null -ne $g.pmax -and $null -ne $g.pdef) {
      $cap = [math]::Min($g.pmax, [math]::Floor($g.pdef * $Lim.capPct / 100))
      $gpuInfo = @{ name = $g.name; plim = $g.plim; pdef = $g.pdef; cap = $cap }
      $items += @{ name = 'Graphics card'; detail = "$($g.name), $($g.temp) C, power limit $($g.plim) W (stock $($g.pdef) W)"; status = 'AVAILABLE'; note = "Power-limit tuning, safety cap $cap W" }
    } else {
      $gn = (@(Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }) -join ', ')
      $items += @{ name = 'Graphics card'; detail = $gn; status = 'UNSUPPORTED'; note = 'Needs an NVIDIA GPU with nvidia-smi and readable power limits' }
    }
    $xtu = (Test-Path "$env:ProgramFiles\Intel\Intel(R) Extreme Tuning Utility") -or (Test-Path "$env:ProgramFiles\AMD\RyzenMaster")
    $ctxt = if ($null -ne $tel.cpuTemp) { "$($tel.cpuTemp) C" } else { 'temperature UNAVAILABLE' }
    $cnote = if ($xtu) { 'A vendor tuning tool is installed, but Hamziopti cannot control it safely' } else { 'Multiplier and voltage need a vendor driver tool (Intel XTU, AMD Ryzen Master)' }
    $items += @{ name = 'Processor'; detail = "$($cpu.Name.Trim()), $($cpu.CurrentClockSpeed) of $($cpu.MaxClockSpeed) MHz, $ctxt"; status = 'UNSUPPORTED'; note = $cnote }
    $items += @{ name = 'Memory'; detail = "$([math]::Round(($ram | Measure-Object Capacity -Sum).Sum / 1GB, 0)) GB at $($ram[0].ConfiguredClockSpeed) MHz"; status = 'UNSUPPORTED'; note = 'XMP/EXPO and timings are set in the BIOS only' }
    $items += @{ name = 'Board and BIOS'; detail = "$($bb.Manufacturer) $($bb.Product), BIOS $($bios.SMBIOSBIOSVersion)"; status = 'UNSUPPORTED'; note = 'No safe Windows interface for firmware settings' }
    $items += @{ name = 'Cooling'; detail = 'Fans and coolers are not readable by Windows'; status = 'UNKNOWN'; note = 'Watch the temperatures during tests' }
    @{ admin = (Test-Admin); items = $items; gpu = $gpuInfo; recovered = $script:Recovered }
  }
  $script:OC = Load-Oc; $script:Recovered = $null
  if ($script:OC.status -in 'tuning', 'recover') {
    $script:Recovered = if (Invoke-OcRollback $true) { 'The last session ended while tuning. Stock settings were restored and verified.' } else { 'The last session ended while tuning and stock settings could NOT be verified. Restart your PC.' }
  }


  # ================= FPS LAB: game detection + PresentMon capture =================
  $script:Fps = @{ active = $false; proc = ''; game = ''; csv = ''; start = [datetime]::MinValue; secs = 0; result = $null; error = $null; p = $null }
  $script:lastFps = [datetime]::MinValue
  function Get-Pm {
    $f = Get-ChildItem $Root -Filter 'PresentMon*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $f) { return $null }
    $m = [int]$f.VersionInfo.FileMajorPart
    if ($m -lt 1 -and $f.Name -match '(\d+)\.\d+') { $m = [int]$Matches[1] }
    if ($m -lt 1) { $m = 2 }
    @{ path = $f.FullName; major = $m; name = $f.Name }
  }
  function Get-GameList {
    $g = @()
    $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { $steam = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction SilentlyContinue).InstallPath }
    if ($steam) {
      $steam = $steam -replace '/', '\'; $libs = @($steam)
      $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
      if (Test-Path $vdf) { foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') } }
      foreach ($lib in ($libs | Select-Object -Unique)) {
        $sa = Join-Path $lib 'steamapps'; if (-not (Test-Path $sa)) { continue }
        foreach ($f in Get-ChildItem $sa -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue) {
          $t = Get-Content $f.FullName -Raw
          $n = [regex]::Match($t, '"name"\s+"([^"]+)"').Groups[1].Value; $d = [regex]::Match($t, '"installdir"\s+"([^"]+)"').Groups[1].Value; $id = [regex]::Match($t, '"appid"\s+"(\d+)"').Groups[1].Value
          if ($n -and $d -and $n -notmatch 'Steamworks|Proton|Steam Linux|Redistributable') { $g += @{ name = $n; launcher = 'Steam'; dir = (Join-Path $sa "common\$d"); appid = $id } }
        }
      }
    }
    foreach ($f in Get-ChildItem "$env:ProgramData\Epic\EpicGamesLauncher\Data\Manifests" -Filter *.item -ErrorAction SilentlyContinue) {
      try { $j = Get-Content $f.FullName -Raw | ConvertFrom-Json; if ($j.DisplayName -and $j.InstallLocation) { $g += @{ name = $j.DisplayName; launcher = 'Epic'; dir = $j.InstallLocation; appid = $null } } } catch {}
    }
    foreach ($k in Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games' -ErrorAction SilentlyContinue) {
      $p = Get-ItemProperty $k.PSPath; if ($p.gameName -and $p.path) { $g += @{ name = $p.gameName; launcher = 'GOG'; dir = $p.path; appid = $null } }
    }
    $run = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath } | ForEach-Object { @{ name = $_.Name; path = $_.ExecutablePath; ws = [double]$_.WorkingSetSize } })
    $skip = 'crash|unins|EasyAntiCheat|BEService|CefSharp|Redist|setup|helper'
    $out = @()
    foreach ($x in $g) {
      $d = $x.dir.TrimEnd('\') + '\'
      $m = $run | Where-Object { $_.path.StartsWith($d, [StringComparison]::OrdinalIgnoreCase) -and $_.name -notmatch $skip } | Sort-Object { $_.ws } -Descending | Select-Object -First 1
      $out += @{ name = $x.name; launcher = $x.launcher; appid = $x.appid; proc = $(if ($m) { $m.name } else { $null }) }
    }
    $ign = 'explorer|msedge|chrome|firefox|electron|Hamziopti|powershell|ApplicationFrameHost|TextInputHost|SystemSettings|Taskmgr|SearchHost|ShellExperienceHost|WindowsTerminal|cmd'
    $oth = @(Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -and $_.ProcessName -notmatch $ign } | ForEach-Object { @{ name = "$($_.ProcessName).exe"; title = $_.MainWindowTitle } })
    $pm = Get-Pm
    @{ games = @($out | Sort-Object { $_.name }); others = $oth; pm = $(if ($pm) { $pm.name } else { $null }); admin = (Test-Admin) }
  }
  function Read-Fps($csv) {
    if (-not (Test-Path $csv)) { return $null }
    $lines = [IO.File]::ReadAllLines($csv); if ($lines.Count -lt 12) { return $null }
    $h = $lines[0].Split(','); $ix = -1
    for ($i = 0; $i -lt $h.Count; $i++) { if ($h[$i] -match '^(msbetweenpresents|frametime)$') { $ix = $i; break } }
    if ($ix -lt 0) { return $null }
    $ft = New-Object 'System.Collections.Generic.List[double]'
    for ($i = 1; $i -lt $lines.Count; $i++) { $f = $lines[$i].Split(','); if ($f.Count -gt $ix) { $d = Num $f[$ix]; if ($null -ne $d -and $d -gt 0) { $ft.Add($d) } } }
    $n = $ft.Count; if ($n -lt 10) { return $null }
    $a = $ft.ToArray(); [Array]::Sort($a); $sum = 0.0; foreach ($v in $a) { $sum += $v }
    $med = $a[[int][math]::Floor($n / 2)]; $p99 = $a[[int][math]::Min($n - 1, [math]::Floor($n * 0.99))]; $p999 = $a[[int][math]::Min($n - 1, [math]::Floor($n * 0.999))]
    $st = 0; foreach ($v in $a) { if ($v -gt 2 * $med) { $st++ } }
    $step = [int][math]::Ceiling($n / 240); $series = @()
    for ($i = 0; $i -lt $n; $i += $step) { $e = [math]::Min($n, $i + $step); $t = 0.0; for ($j = $i; $j -lt $e; $j++) { $t += $ft[$j] }; $series += [math]::Round(1000 * ($e - $i) / $t, 1) }
    @{ frames = $n; avg = [math]::Round(1000 * $n / $sum, 1); low1 = [math]::Round(1000 / $p99, 1); low01 = [math]::Round(1000 / $p999, 1); maxMs = [math]::Round($a[$n - 1], 1); stutters = $st; series = $series }
  }
  function Start-Fps($proc, $secs, $game) {
    if ($script:Fps.active) { return @{ ok = $false; error = 'A measurement is already running' } }
    $pm = Get-Pm; if (-not $pm) { return @{ ok = $false; error = 'nopm' } }
    if ($proc -notmatch '^[\w\.\- \(\)]+\.exe$') { return @{ ok = $false; error = 'Invalid program name' } }
    $secs = [math]::Min(300, [math]::Max(10, $secs))
    $dir = Join-Path $Data 'fps'; New-Item -ItemType Directory -Force $dir | Out-Null
    $csv = Join-Path $dir ("fps-$(Get-Date -f yyyyMMdd-HHmmss).csv")
    $a = if ($pm.major -ge 2) { "--process_name `"$proc`" --output_file `"$csv`" --no_console_stats --timed $secs --terminate_after_timed" } else { "-process_name `"$proc`" -output_file `"$csv`" -timed $secs -terminate_after_timed -no_top" }
    $p = Start-Process -FilePath $pm.path -ArgumentList $a -WindowStyle Hidden -PassThru
    $F = $script:Fps; $F.active = $true; $F.proc = $proc; $F.game = $game; $F.csv = $csv; $F.start = Get-Date; $F.secs = $secs; $F.result = $null; $F.error = $null; $F.p = $p
    @{ ok = $true }
  }
  function Invoke-FpsMonitor {
    $F = $script:Fps; if (-not $F.active) { return }
    if (((Get-Date) - $script:lastFps).TotalMilliseconds -lt 900) { return }; $script:lastFps = Get-Date
    $over = ((Get-Date) - $F.start).TotalSeconds -gt ($F.secs + 20)
    if ($F.p.HasExited -or $over) {
      if (-not $F.p.HasExited) { try { $F.p.Kill() } catch {} }
      $F.active = $false; $r = Read-Fps $F.csv
      if ($r) { $g = Get-Gpu; $ids = @(@(Get-Backup) | ForEach-Object { $_.tweak } | Select-Object -Unique); $r.ctx = @{ tweaks = $ids; gpu = $g.name; limit = $g.plim; stock = $g.pdef }; $F.result = $r }
      else { $F.error = 'No frames were captured. Keep the game running and in front, and run Hamziopti as administrator.' }
    }
  }

  # ---- local server ----
  $port = if ($Port -gt 0) { $Port } else { Get-Random -Minimum 49152 -Maximum 65000 }
  $token = if ($Token) { $Token } else { [guid]::NewGuid().ToString('N') }
  $l = New-Object Net.HttpListener
  $l.Prefixes.Add("http://127.0.0.1:$port/"); $l.Start()
  $url = "http://127.0.0.1:$port/?t=$token"
  if (-not $NoBrowser) {
    $exe = $null
    foreach ($k in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe') {
      $v = (Get-ItemProperty $k -ErrorAction SilentlyContinue).'(default)'
      if ($v -and (Test-Path $v)) { $exe = $v; break }
    }
    if (-not $exe) { $exe = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe" }
    if (Test-Path $exe) { Start-Process $exe "--app=$url --user-data-dir=`"$Data\browser`" --window-size=1320,840" } else { Start-Process $url }
  }

  function Send($c, $body, $type, $code = 200) {
    $b = if ($body -is [byte[]]) { $body } else { [Text.Encoding]::UTF8.GetBytes($body) }
    $c.Response.StatusCode = $code; $c.Response.ContentType = $type
    $c.Response.OutputStream.Write($b, 0, $b.Length); $c.Response.Close()
  }
  $last = Get-Date; $limit = 300; $run = $true
  while ($run) {
    Invoke-Monitor; Invoke-FpsMonitor
    $t = $l.GetContextAsync()
    while (-not $t.Wait(1000)) { Invoke-Monitor; Invoke-FpsMonitor; if (((Get-Date) - $last).TotalSeconds -gt $limit -and -not $script:Test.active -and -not $script:Fps.active) { $run = $false; break } }
    if (-not $run) { break }
    $c = $t.Result; $last = Get-Date; $path = $c.Request.Url.AbsolutePath
    try {
      if ($path -eq '/') { Send $c ([IO.File]::ReadAllBytes("$Root\index.html")) 'text/html; charset=utf-8'; continue }
      if ($path -eq '/icon.ico') { Send $c ([IO.File]::ReadAllBytes("$Root\Hamziopti.ico")) 'image/x-icon'; continue }
      if ($c.Request.Headers['X-Token'] -ne $token) { Send $c '{"error":"forbidden"}' 'application/json' 403; continue }
      $body = $null
      if ($c.Request.HasEntityBody) { $body = (New-Object IO.StreamReader($c.Request.InputStream)).ReadToEnd() | ConvertFrom-Json }
      $out = switch ($path) {
        '/api/ping' { @{ ok = $true } }
        '/api/cpu' { @{ load = [int](Get-CimInstance Win32_Processor | Measure-Object LoadPercentage -Average).Average } }
        '/api/scan' { Get-Scan }
        '/api/state' {
          $bk = @(Get-Backup)
          @{ tweaks = @($Tweaks | ForEach-Object { $i = $_.id; @{ id = $i; name = $_.name; desc = $_.desc; cat = $_.cat; applied = [bool]($bk | Where-Object { $_.tweak -eq $i }) } })
             startup = @(Get-Startup); backups = $bk.Count }
        }
        '/api/apply' { @{ results = @(Invoke-Apply @($body.ids)) } }
        '/api/restore' { @{ restored = Invoke-Restore } }
        '/api/startup' { Set-Startup $body.name ([bool]$body.enabled); @{ ok = $true } }
        '/api/clean' { Invoke-Clean }
        '/api/quit' { $run = $false; @{ ok = $true } }
        '/api/oc/scan' { Get-OcScan }
        '/api/oc/status' { Get-OcStatus }
        '/api/oc/baseline' {
          if ($script:OC.status -eq 'tuning') { @{ ok = $false; error = 'Baseline must be recorded at stock settings' } }
          else { $script:OC.baseline = @{ gpuScore = [double]$body.gpuScore; K = [int]$body.K; p99 = [double]$body.p99; cpuRate = [double]$body.cpuRate; peakGpu = [double]$body.peakGpu }; OcLog 'Baseline recorded at stock settings'; @{ ok = $true } }
        }
        '/api/oc/test' { Start-OcTest "$($body.kind)" ([int]$body.secs) }
        '/api/oc/step' { Invoke-OcStep ([double]$body.watts) }
        '/api/oc/accept' { $script:OC.lastGood = [double]$body.watts; OcLog "Accepted $($body.watts) W as last verified setting"; @{ ok = $true } }
        '/api/oc/reject' { $script:OC.rejected = @(@($script:OC.rejected) + "$($body.watts) W: $($body.reason)"); OcLog "Rejected $($body.watts) W: $($body.reason)"; @{ ok = (Invoke-OcRollback) } }
        '/api/oc/stock' { @{ ok = (Invoke-OcRollback $true) } }
        '/api/oc/stop' { if ($script:BurnOk) { [Burn]::Stop = $true }; $script:Test.active = $false; $script:Test.aborted = 'Stopped by you'; @{ ok = $true } }
        '/api/games' { Get-GameList }
        '/api/fps/start' { Start-Fps "$($body.proc)" ([int]$body.secs) "$($body.game)" }
        '/api/fps/status' { $F = $script:Fps; @{ active = $F.active; remaining = [int][math]::Max(0, $F.secs - ((Get-Date) - $F.start).TotalSeconds); proc = $F.proc; game = $F.game; error = $F.error; result = $F.result } }
        '/api/fps/stop' { if ($script:Fps.active) { try { $script:Fps.p.Kill() } catch {} }; @{ ok = $true } }
        '/api/launch' { if ("$($body.appid)" -match '^\d+$') { Start-Process "steam://rungameid/$($body.appid)"; @{ ok = $true } } else { @{ ok = $false } } }
        '/api/openpm' { Start-Process 'https://github.com/GameTechDev/PresentMon/releases'; @{ ok = $true } }
        default { @{ error = 'not found' } }
      }
      Send $c (ConvertTo-Json -InputObject $out -Depth 6 -Compress) 'application/json; charset=utf-8'
    } catch {
      try { Send $c (ConvertTo-Json @{ error = $_.Exception.Message }) 'application/json' 500 } catch {}
    }
  }
  $l.Stop()
  if ($script:BurnOk) { [Burn]::Stop = $true }
  if ($script:OC.status -eq 'tuning') { [void](Invoke-OcRollback $true) }
} catch { Fail $_.Exception.Message }
